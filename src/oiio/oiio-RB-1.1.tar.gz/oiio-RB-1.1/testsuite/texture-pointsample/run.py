#!/usr/bin/python 

command = testtex_command (parent + "/oiio-images/grid.tx", " -width 0")
outputs = [ "out.exr" ]
