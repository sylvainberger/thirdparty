#!/usr/bin/python 

command = testtex_command ("vertgrid.tx", " --scalest 4 1 ")
outputs = [ "out.exr" ]
