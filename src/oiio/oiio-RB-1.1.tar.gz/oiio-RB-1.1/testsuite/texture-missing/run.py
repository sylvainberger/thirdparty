#!/usr/bin/python 

command = testtex_command ("missing.tx", "--missing 1 0 0 --res 8 8 missing.tx")
outputs = [ "out.exr" ]
