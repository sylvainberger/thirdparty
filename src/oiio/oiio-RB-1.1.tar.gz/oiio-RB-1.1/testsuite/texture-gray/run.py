#!/usr/bin/python 

command = testtex_command ("gray.png", " -fill 0.05 --graytorgb --res 128 128 --nowarp ")
outputs = [ "out.exr" ]
