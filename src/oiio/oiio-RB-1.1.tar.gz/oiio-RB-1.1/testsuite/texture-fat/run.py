#!/usr/bin/python 

command = testtex_command ("horizgrid.tx", " --scalest 1 4")
outputs = [ "out.exr" ]
