#!/usr/bin/python 

command = testtex_command (parent + "/oiio-images/grid.tx")
outputs = [ "out.exr" ]
