#!/usr/bin/python 

imagedir = parent + "/oiio-images"
command = rw_command (imagedir, "oiio.ico")
