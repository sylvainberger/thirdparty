
class Constants:
    
    def __init__(self):
        pass
    
    def GetInverseTransformDirection(self, direction):
        """
        GetInverseTransformDirection(direction)
        
        :param s:
        :param type: string
        """
        pass
    
    def CombineTransformDirections(self, dir1, dir2):
        """
        CombineTransformDirections(dir1, dir2)
        
        :param s1:
        :param type: string
        :param s2:
        :param type: string
        """
        pass
        
    def BitDepthIsFloat(self, bitDepth):
        """
        BitDepthIsFloat(bitDepth)
        
        :param s:
        :param type: string
        """
        pass
        
    def BitDepthToInt(self, bitDepth):
        """
        BitDepthToInt(bitDepth)
        
        :param s:
        :param type: string
        """
        pass
