
class LookTransform:
    """
    LookTransform
    """
    def __init__(self):
        pass
    def getSrc(self):
        pass
    def setSrc(self, srcname):
        pass
    def getDst(self):
        pass
    def setDst(self, dstname):
        pass
    def getLooks(self):
        pass
    def setLooks(self, looks):
        pass
