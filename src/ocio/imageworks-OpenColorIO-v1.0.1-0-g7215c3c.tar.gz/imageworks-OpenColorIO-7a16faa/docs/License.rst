.. license:

License
=======
.. include:: LICENSE
